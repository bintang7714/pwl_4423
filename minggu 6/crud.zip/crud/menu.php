<div class="menu">
    <ul>
        <li><a href="index.php?p=home">Home</a></li>
        <li><a href="index.php?p=sekolah">Sekolah</a></li>
    </ul>

</div>