<h1>welcome to pdo crud!</h1>
<h2>Tambah data sekolah</h2>
<form method="post" action="proses/sekolah.save.php" enctype="multipart/form-data">
    <table>
        <tr>
            <td>Nama</td>
            <td><input type="text" name="nama" value=""></td>

        </tr>

        <tr>
            <td>Alamat</td>
            <td><input type="text" name="alamat" value=""></td>
        </tr>

        <tr>
            <td>Logo</td>
            <td><input type="text" name="logo" value=""></td>
        </tr>

        <tr>
            <td></td>
            <td><button type="submit" name="">Simpan</button></td>
        </tr>

    </table>
   
</form>